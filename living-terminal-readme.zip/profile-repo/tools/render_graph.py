#!/usr/bin/env python3
"""
render_graph.py
Draws graph.svg from assets/contributions.json — the ~53-week x 7-day
contribution grid, revealed column by column (a wave sweeping left to
right) rather than the more common row-by-row wipe.

Stdlib only. Run after pull_contributions.py (or make_sample_contributions.py
for a preview) has written assets/contributions.json.
"""
import json
import os
from datetime import date

# --- design tokens -------------------------------------------------------
BG        = "#0a0e14"
AMBER     = "#ffb020"
AMBER_DIM = "#7a5410"
RULE      = "#3a2f1a"
TEXT_DIM  = "#7a5410"
FONT      = "ui-monospace, 'SFMono-Regular', Menlo, Consolas, 'Liberation Mono', monospace"

LEVELS = ["#1a140a", "#4d3814", "#7a5410", "#c98a1c", "#ffb020"]

CELL = 11
GAP = 3
PAD = 24
PREVIEW = os.environ.get("PREVIEW") == "1"


def level_for(count, max_count):
    if count == 0 or max_count == 0:
        return 0
    ratio = count / max_count
    if ratio > 0.75:
        return 4
    if ratio > 0.5:
        return 3
    if ratio > 0.25:
        return 2
    return 1


def load():
    with open("assets/contributions.json") as f:
        return json.load(f)


def to_weeks(days):
    """Group day entries into calendar weeks (columns), Sun-start."""
    weeks = []
    current = []
    for entry in days:
        y, m, d = map(int, entry["date"].split("-"))
        wd = date(y, m, d).weekday()  # Mon=0 .. Sun=6
        sun_index = (wd + 1) % 7      # Sun=0 .. Sat=6
        if sun_index == 0 and current:
            weeks.append(current)
            current = []
        current.append(entry)
    if current:
        weeks.append(current)
    return weeks


def build(data):
    days = data["days"]
    max_count = max((x["count"] for x in days), default=0)
    weeks = to_weeks(days)

    grid_w = len(weeks) * (CELL + GAP)
    grid_h = 7 * (CELL + GAP)
    W = grid_w + PAD * 2
    H = grid_h + PAD * 2 + 60  # room for stats line + legend

    squares = []
    for wi, week in enumerate(weeks):
        begin = wi * 0.018
        anim = "" if PREVIEW else (
            f'<animate attributeName="opacity" from="0" to="1" '
            f'begin="{begin:.3f}s" dur="0.25s" fill="freeze" />'
        )
        opacity = "1" if PREVIEW else "0"
        cells = []
        for entry in week:
            y, m, d = map(int, entry["date"].split("-"))
            wd = date(y, m, d).weekday()
            row = (wd + 1) % 7
            x = PAD + wi * (CELL + GAP)
            y_pos = PAD + row * (CELL + GAP)
            color = LEVELS[level_for(entry["count"], max_count)]
            cells.append(
                f'<rect x="{x}" y="{y_pos}" width="{CELL}" height="{CELL}" rx="2" fill="{color}"/>'
            )
        squares.append(f'<g opacity="{opacity}">{anim}{"".join(cells)}</g>')

    legend_x = PAD
    legend_y = PAD + grid_h + 34
    legend_cells = "".join(
        f'<rect x="{legend_x + 34 + i * (CELL + GAP)}" y="{legend_y - 9}" '
        f'width="{CELL}" height="{CELL}" rx="2" fill="{c}"/>'
        for i, c in enumerate(LEVELS)
    )

    stats = (
        f'{data["total"]} contributions in the last year  .  '
        f'current streak {data["current_streak"]}d  .  '
        f'longest streak {data["longest_streak"]}d  .  '
        f'busiest day {data["busiest_day"]}'
    )

    svg = f'''<svg viewBox="0 0 {W} {H}" width="{W}" height="{H}" xmlns="http://www.w3.org/2000/svg">
  <rect x="0" y="0" width="{W}" height="{H}" rx="10" fill="{BG}" stroke="{RULE}" stroke-width="1.5"/>
  {"".join(squares)}
  <text x="{PAD}" y="{legend_y + 1}" font-family="{FONT}" font-size="12" fill="{TEXT_DIM}">less</text>
  {legend_cells}
  <text x="{legend_x + 34 + 5 * (CELL + GAP) + 8}" y="{legend_y + 1}" font-family="{FONT}" font-size="12" fill="{TEXT_DIM}">more</text>
  <text x="{W - PAD}" y="{legend_y + 1}" text-anchor="end" font-family="{FONT}" font-size="12" fill="{AMBER}">{stats}</text>
</svg>'''
    return svg


if __name__ == "__main__":
    data = load()
    out = build(data)
    with open("graph.svg", "w") as f:
        f.write(out)
    print("wrote graph.svg")
