#!/usr/bin/env python3
"""
render_portrait.py
Stage 2 of the portrait pipeline: maps assets/photo-ready.png to a grid of
ASCII glyphs and animates it drawing in, row by row, using a clip-rect
width animation staggered ~40ms apart. Once this same output path
(portrait.svg) exists, it replaces tools/render_portrait_placeholder.py's
monogram — both write to the same file.

Run this locally (not in CI):
    pip install -r tools/requirements-art.txt
    python tools/render_portrait.py
    # writes portrait.svg
"""
from PIL import Image

# left = light/empty, right = dense/dark — softer read than the usual @%#
GLYPHS = " '.,:;~+*xXO#"

BG    = "#0a0e14"
AMBER = "#ffb020"
FONT  = "ui-monospace, 'SFMono-Regular', Menlo, Consolas, 'Liberation Mono', monospace"

COLS = 70          # character columns — tune for detail vs. size
CELL_W = 7.2        # px per character cell, monospace-ish
CELL_H = 12
ROW_STAGGER = 0.04  # seconds between row starts, per the walkthrough


def load_grid(path="assets/photo-ready.png"):
    img = Image.open(path).convert("L")
    w, h = img.size
    # character cells are taller than wide, so undersample rows to keep
    # the portrait's proportions correct
    cols = COLS
    rows = int(cols * (h / w) * (CELL_W / CELL_H))
    small = img.resize((cols, rows))
    return small, cols, rows


def esc(s):
    return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")


def build():
    img, cols, rows = load_grid()
    px = img.load()

    W = cols * CELL_W + 20
    H = rows * CELL_H + 20

    row_groups = []
    for r in range(rows):
        chars = []
        for c in range(cols):
            brightness = px[c, r] / 255.0  # 1.0 = white/light, 0.0 = black/dense
            idx = int((1 - brightness) * (len(GLYPHS) - 1))
            glyph = GLYPHS[idx]
            if glyph == " ":
                continue
            x = 10 + c * CELL_W
            chars.append(f'<tspan x="{x:.1f}">{esc(glyph)}</tspan>')
        if not chars:
            continue
        y = 10 + (r + 1) * CELL_H
        begin = r * ROW_STAGGER
        clip_id = f"row{r}"
        row_groups.append(f'''
  <clipPath id="{clip_id}">
    <rect x="0" y="{y - CELL_H}" width="0" height="{CELL_H + 2}">
      <animate attributeName="width" from="0" to="{W}" begin="{begin:.2f}s" dur="0.3s" fill="freeze" />
    </rect>
  </clipPath>
  <text clip-path="url(#{clip_id})" y="{y}" font-family="{FONT}" font-size="{CELL_H - 1}" fill="{AMBER}">{"".join(chars)}</text>''')

    total_time = rows * ROW_STAGGER + 0.3
    cursor_y = 10 + rows * CELL_H
    blink = (
        f'<animate attributeName="opacity" values="1;1;0;0;1" keyTimes="0;0.5;0.5;1;1" '
        f'begin="{total_time + 0.2:.2f}s" dur="1s" repeatCount="indefinite" />'
    )

    svg = f'''<svg viewBox="0 0 {W:.0f} {H:.0f}" width="{W:.0f}" height="{H:.0f}" xmlns="http://www.w3.org/2000/svg">
  <rect x="0" y="0" width="{W:.0f}" height="{H:.0f}" rx="10" fill="{BG}"/>
  {"".join(row_groups)}
  <rect x="10" y="{cursor_y - 10}" width="7" height="12" fill="{AMBER}" opacity="0">
    <set attributeName="opacity" to="1" begin="{total_time + 0.2:.2f}s" />
    {blink}
  </rect>
</svg>'''
    return svg


if __name__ == "__main__":
    out = build()
    with open("portrait.svg", "w") as f:
        f.write(out)
    print("wrote portrait.svg")
