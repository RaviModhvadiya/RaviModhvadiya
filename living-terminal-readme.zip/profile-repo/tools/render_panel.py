#!/usr/bin/env python3
"""
render_panel.py
Draws sysinfo.svg — a terminal-style info panel that types itself out.
Stdlib only, no dependencies. Safe to run in CI.

Usage:
    python tools/render_panel.py            # writes sysinfo.svg
    PREVIEW=1 python tools/render_panel.py   # freezes the last frame for
                                              # quick viewing in a normal
                                              # image viewer
"""
import os

# --- content -----------------------------------------------------------
# Edit these rows freely — this is the only part of the file you should
# need to touch day to day.
ROWS = [
    ("user",  "ravimodhvadiya"),
    ("role",  "college student"),
    ("stack", "C . Java . Python . JS . SQL"),
    ("tools", "Git . GitHub . Figma . Jira"),
    ("now",   "open to internships & collab"),
]

# --- design tokens -------------------------------------------------------
BG       = "#0a0e14"
AMBER    = "#ffb020"
AMBER_DIM = "#7a5410"
RULE     = "#3a2f1a"
FONT     = "ui-monospace, 'SFMono-Regular', Menlo, Consolas, 'Liberation Mono', monospace"

W, H = 460, 260
PAD = 24
ROW_H = 30
LABEL_W = 90
PREVIEW = os.environ.get("PREVIEW") == "1"


def esc(s):
    return (s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;"))


def row_svg(i, label, value):
    y = PAD + 44 + i * ROW_H
    begin = 0.3 + i * 0.15
    anim = "" if PREVIEW else (
        f'<animate attributeName="opacity" from="0" to="1" '
        f'begin="{begin:.2f}s" dur="0.35s" fill="freeze" />'
    )
    opacity = "1" if PREVIEW else "0"
    return f'''
  <g opacity="{opacity}">
    {anim}
    <text x="{PAD}" y="{y}" font-family="{FONT}" font-size="14" fill="{AMBER_DIM}">{esc(label)}</text>
    <text x="{PAD + LABEL_W}" y="{y}" font-family="{FONT}" font-size="14" fill="{AMBER}">{esc(value)}</text>
  </g>'''


def build():
    rows_svg = "".join(row_svg(i, l, v) for i, (l, v) in enumerate(ROWS))
    cursor_x = PAD + LABEL_W
    cursor_y_row = len(ROWS) - 1
    cursor_y = PAD + 44 + cursor_y_row * ROW_H + 4
    # cursor appears after the last row has finished typing, then blinks forever
    cursor_begin = 0.3 + cursor_y_row * 0.15 + 0.4
    cursor_text_width = len(ROWS[-1][1]) * 8.4
    blink = "" if PREVIEW else (
        f'<animate attributeName="opacity" values="1;1;0;0;1" keyTimes="0;0.5;0.5;1;1" '
        f'begin="{cursor_begin:.2f}s" dur="1s" repeatCount="indefinite" />'
    )
    cursor_opacity = "1" if PREVIEW else "0"
    cursor_appear = "" if PREVIEW else (
        f'<set attributeName="opacity" to="1" begin="{cursor_begin:.2f}s" />'
    )

    svg = f'''<svg viewBox="0 0 {W} {H}" width="{W}" height="{H}" xmlns="http://www.w3.org/2000/svg">
  <rect x="0" y="0" width="{W}" height="{H}" rx="10" fill="{BG}" stroke="{RULE}" stroke-width="1.5"/>
  <text x="{PAD}" y="{PAD + 12}" font-family="{FONT}" font-size="13" letter-spacing="2" fill="{AMBER_DIM}">SYSINFO</text>
  <line x1="{PAD}" y1="{PAD + 22}" x2="{W - PAD}" y2="{PAD + 22}" stroke="{RULE}" stroke-width="1"/>
  {rows_svg}
  <rect x="{cursor_x + cursor_text_width}" y="{cursor_y - 12}" width="8" height="14" fill="{AMBER}" opacity="{cursor_opacity}">
    {cursor_appear}
    {blink}
  </rect>
</svg>'''
    return svg


if __name__ == "__main__":
    out = build()
    path = "sysinfo.svg"
    with open(path, "w") as f:
        f.write(out)
    print(f"wrote {path}")
