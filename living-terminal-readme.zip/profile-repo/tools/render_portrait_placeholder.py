#!/usr/bin/env python3
"""
render_portrait_placeholder.py
Draws portrait.svg as an animated ASCII monogram, row by row, using the
same clip-reveal technique the real photo-based renderer (render_portrait.py)
uses. This is a stand-in for when you don't have a source photo yet — once
you do, run tools/clean_photo.py + tools/render_portrait.py instead, which
overwrite the same portrait.svg output path.

Stdlib only, no dependencies.
"""
import os

BG    = "#0a0e14"
AMBER = "#ffb020"
FONT  = "ui-monospace, 'SFMono-Regular', Menlo, Consolas, 'Liberation Mono', monospace"
PREVIEW = os.environ.get("PREVIEW") == "1"

# 5x7 block-letter bitmaps, 1 = lit cell
GLYPHS = {
    "R": [
        "1111 ",
        "1   1",
        "1   1",
        "1111 ",
        "1 1  ",
        "1  1 ",
        "1   1",
    ],
    "M": [
        "1   1",
        "11 11",
        "1 1 1",
        "1   1",
        "1   1",
        "1   1",
        "1   1",
    ],
}

CELL = 22
GAP_BETWEEN_LETTERS = 1


def build_grid(letters):
    rows = 7
    grid = []
    for r in range(rows):
        line = ""
        for i, ch in enumerate(letters):
            line += GLYPHS[ch][r]
            if i != len(letters) - 1:
                line += " " * GAP_BETWEEN_LETTERS
        grid.append(line)
    return grid


def build():
    grid = build_grid(["R", "M"])
    cols = len(grid[0])
    rows = len(grid)
    grid_w = cols * CELL
    grid_h = rows * CELL
    pad = 30
    label = "ravimodhvadiya"
    W = grid_w + pad * 2
    H = grid_h + pad * 2 + 40

    row_groups = []
    for r, line in enumerate(grid):
        cells = []
        for c, ch in enumerate(line):
            if ch != "1":
                continue
            x = pad + c * CELL
            y = pad + r * CELL
            cells.append(
                f'<rect x="{x}" y="{y}" width="{CELL - 4}" height="{CELL - 4}" rx="3" fill="{AMBER}"/>'
            )
        if not cells:
            continue
        begin = r * 0.09
        clip_id = f"clip{r}"
        anim = "" if PREVIEW else (
            f'<animate attributeName="width" from="0" to="{grid_w}" '
            f'begin="{begin:.2f}s" dur="0.35s" fill="freeze" />'
        )
        clip_width = grid_w if PREVIEW else 0
        row_groups.append(f'''
  <clipPath id="{clip_id}">
    <rect x="{pad}" y="{pad + r * CELL}" width="{clip_width}" height="{CELL}">
      {anim}
    </rect>
  </clipPath>
  <g clip-path="url(#{clip_id})">{"".join(cells)}</g>''')

    total_time = rows * 0.09 + 0.35
    label_y = pad + grid_h + 30
    label_anim = "" if PREVIEW else (
        f'<animate attributeName="opacity" from="0" to="1" '
        f'begin="{total_time:.2f}s" dur="0.4s" fill="freeze" />'
    )
    label_opacity = "1" if PREVIEW else "0"

    cursor_x = pad + len(label) * 8.4
    blink = "" if PREVIEW else (
        f'<animate attributeName="opacity" values="1;1;0;0;1" keyTimes="0;0.5;0.5;1;1" '
        f'begin="{total_time + 0.4:.2f}s" dur="1s" repeatCount="indefinite" />'
    )

    svg = f'''<svg viewBox="0 0 {W} {H}" width="{W}" height="{H}" xmlns="http://www.w3.org/2000/svg">
  <rect x="0" y="0" width="{W}" height="{H}" rx="10" fill="{BG}"/>
  {"".join(row_groups)}
  <g opacity="{label_opacity}">
    {label_anim}
    <text x="{pad}" y="{label_y}" font-family="{FONT}" font-size="14" fill="{AMBER}">{label}</text>
  </g>
  <rect x="{cursor_x}" y="{label_y - 12}" width="8" height="14" fill="{AMBER}" opacity="0">
    <set attributeName="opacity" to="1" begin="{total_time + 0.4:.2f}s" />
    {blink}
  </rect>
</svg>'''
    return svg


if __name__ == "__main__":
    out = build()
    with open("portrait.svg", "w") as f:
        f.write(out)
    print("wrote portrait.svg (placeholder monogram)")
