#!/usr/bin/env python3
"""
clean_photo.py
Stage 1 of the portrait pipeline: takes a raw photo and produces a clean
subject-on-white image that converts to ASCII well.

    1. Cut the background out with rembg.
    2. Even out lighting with CLAHE (adaptive histogram equalization).
    3. Composite onto a plain white canvas.

Run this locally (not in CI) — the dependencies are heavy:
    pip install -r tools/requirements-art.txt

Usage:
    python tools/clean_photo.py my-photo.jpg
    # writes assets/photo-ready.png
"""
import sys

import cv2
import numpy as np
from PIL import Image
from rembg import remove


def clean(src_path, dst_path="assets/photo-ready.png"):
    with open(src_path, "rb") as f:
        raw = f.read()

    # 1. background removal -> RGBA with transparent background
    cutout = remove(raw)
    img = Image.open(__import__("io").BytesIO(cutout)).convert("RGBA")

    # 2. CLAHE on the luminance channel of the RGB part
    arr = np.array(img)
    rgb = arr[:, :, :3]
    alpha = arr[:, :, 3]

    lab = cv2.cvtColor(rgb, cv2.COLOR_RGB2LAB)
    l, a, b = cv2.split(lab)
    clahe = cv2.createCLAHE(clipLimit=2.5, tileGridSize=(8, 8))
    l = clahe.apply(l)
    lab = cv2.merge((l, a, b))
    rgb_eq = cv2.cvtColor(lab, cv2.COLOR_LAB2RGB)

    # 3. composite onto white
    canvas = np.full_like(rgb_eq, 255)
    alpha_f = (alpha.astype(np.float32) / 255.0)[..., None]
    composited = (rgb_eq.astype(np.float32) * alpha_f + canvas.astype(np.float32) * (1 - alpha_f))
    out = Image.fromarray(composited.astype(np.uint8), "RGB")

    out.save(dst_path)
    print(f"wrote {dst_path}")


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("usage: python tools/clean_photo.py <path-to-photo>")
        sys.exit(1)
    clean(sys.argv[1])
