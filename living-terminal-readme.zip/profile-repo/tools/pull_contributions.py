#!/usr/bin/env python3
"""
pull_contributions.py
Pulls your real contribution calendar with no OAuth / token needed, by
fetching the same HTML fragment GitHub's own profile page consumes:

    https://github.com/users/<username>/contributions

Parses it into assets/contributions.json, which render_graph.py then
draws. This is the piece the daily GitHub Action runs.

Requires: tools/requirements-daily.txt (httpx, lxml)
"""
import json
import re
from datetime import date, timedelta

import httpx
from lxml import html

USERNAME = "RaviModhvadiya"
URL = f"https://github.com/users/{USERNAME}/contributions"


def fetch():
    resp = httpx.get(URL, headers={"User-Agent": "living-terminal-readme"}, timeout=20)
    resp.raise_for_status()
    return resp.text


def parse(fragment_html):
    tree = html.fromstring(fragment_html)
    cells = tree.xpath("//td[@data-date]") or tree.xpath("//*[@data-date]")

    days = []
    for cell in cells:
        d = cell.get("data-date")
        if not d:
            continue
        level_attr = cell.get("data-level")
        count_attr = cell.get("data-count")
        if count_attr is not None:
            count = int(count_attr)
        else:
            # fall back to parsing the tooltip text, e.g. "3 contributions on ..."
            tooltip_id = cell.get("aria-labelledby") or cell.get("id")
            m = re.search(r"(\d+)\s+contribution", cell.get("aria-label", "") or "")
            count = int(m.group(1)) if m else 0
        days.append({"date": d, "count": count})

    days.sort(key=lambda x: x["date"])
    return days


def summarize(days):
    total = sum(x["count"] for x in days)

    cur_streak = 0
    for entry in reversed(days):
        if entry["count"] > 0:
            cur_streak += 1
        else:
            break

    longest = 0
    running = 0
    for entry in days:
        if entry["count"] > 0:
            running += 1
            longest = max(longest, running)
        else:
            running = 0

    by_weekday = [0] * 7
    for entry in days:
        y, m, d = map(int, entry["date"].split("-"))
        by_weekday[date(y, m, d).weekday()] += entry["count"]
    weekday_names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]
    busiest_day = weekday_names[max(range(7), key=lambda i: by_weekday[i])]

    return {
        "generated": date.today().isoformat(),
        "total": total,
        "current_streak": cur_streak,
        "longest_streak": longest,
        "busiest_day": busiest_day,
        "days": days,
    }


if __name__ == "__main__":
    days = parse(fetch())
    data = summarize(days)
    with open("assets/contributions.json", "w") as f:
        json.dump(data, f, indent=2)
    print(f"wrote assets/contributions.json ({data['total']} contributions)")
