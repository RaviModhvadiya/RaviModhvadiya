#!/usr/bin/env python3
"""
make_sample_contributions.py
DEMO ONLY. Fabricates a plausible-looking assets/contributions.json so you
can preview graph.svg before the real daily job (pull_contributions.py)
has ever run. Delete this file once the GitHub Action has committed real
data at least once — it is not part of the production pipeline.
"""
import json
import random
from datetime import date, timedelta

random.seed(7)

end = date.today()
start = end - timedelta(weeks=52, days=end.weekday())  # align to a Sunday-ish start

days = []
d = start
streak = 0
best_streak = 0
cur_streak = 0
by_weekday = [0] * 7  # Mon..Sun

while d <= end:
    # busier on weekdays, quiet-ish on weekends, with random dry spells
    base = 0.75 if d.weekday() < 5 else 0.35
    active = random.random() < base
    count = 0
    if active:
        count = max(1, int(random.gauss(4, 3)))
    days.append({"date": d.isoformat(), "count": count})
    by_weekday[d.weekday()] += count
    if count > 0:
        cur_streak += 1
        best_streak = max(best_streak, cur_streak)
    else:
        cur_streak = 0
    d += timedelta(days=1)

# current streak = trailing streak as of the last day
cur = 0
for entry in reversed(days):
    if entry["count"] > 0:
        cur += 1
    else:
        break

total = sum(x["count"] for x in days)
busiest_idx = max(range(7), key=lambda i: by_weekday[i])
weekday_names = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"]

data = {
    "generated": end.isoformat(),
    "total": total,
    "current_streak": cur,
    "longest_streak": best_streak,
    "busiest_day": weekday_names[busiest_idx],
    "days": days,
}

with open("assets/contributions.json", "w") as f:
    json.dump(data, f, indent=2)

print(f"wrote assets/contributions.json ({total} sample contributions)")
