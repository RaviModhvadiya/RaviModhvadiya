# Optional: custom "Lines of Code" badge

This mirrors the self-generated LOC stat card from CarterPerez's profile repo —
it's separate from the live GitHub widgets already in the main `README.md`
(those need zero setup and update themselves automatically). This one needs
to be run locally because GitHub has no public API for "total lines across
a chosen set of repos," so it can't be a live third-party badge.

## Requirements
- [`tokei`](https://github.com/XAMPPRocky/tokei) — `cargo install tokei`, or via your package manager
- `jq`
- Python 3.9+

## Steps
1. Edit `scripts/repos.json` — replace the placeholder entries with your own
   `"owner/repo"` strings (as many as you want counted).
2. Run:
   ```bash
   ./scripts/count_loc.sh            # clones each repo shallowly, runs tokei -> loc-data.json
   python3 scripts/generate_loc_svg.py   # renders loc-data.json -> dist/loc-stats.svg
   ```
3. Commit `dist/loc-stats.svg`, then add it near the top of `README.md`:
   ```md
   <div align="center">
   <img src="./dist/loc-stats.svg" alt="LOC Stats" width="84%" />
   </div>
   ```
4. Re-run steps 2–3 whenever you want the count refreshed (or wire this into
   a scheduled GitHub Action if you want it to update itself).

The card automatically excludes whatever languages are listed under
`exclude_languages` in `repos.json` (config/data files like JSON/YAML tend to
drown out your actual code if left in).
