#!/usr/bin/env bash
# Tallies lines of code across the repos listed in scripts/repos.json using tokei.
# Requires: git, jq, tokei (https://github.com/XAMPPRocky/tokei)
#
# Usage:
#   ./scripts/count_loc.sh
#
# Output:
#   loc-data.json  (raw tokei report, consumed by generate_loc_svg.py)

set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
REPOS_JSON="$ROOT_DIR/scripts/repos.json"
OUTPUT_FILE="$ROOT_DIR/loc-data.json"
WORK_DIR="$(mktemp -d)"

cleanup() { rm -rf "$WORK_DIR"; }
trap cleanup EXIT

command -v jq    >/dev/null || { echo "error: jq is required"    >&2; exit 1; }
command -v tokei >/dev/null || { echo "error: tokei is required" >&2; exit 1; }

echo "Reading repo list from $REPOS_JSON"
mapfile -t REPOS < <(jq -r '.repos[]' "$REPOS_JSON")

if [ "${#REPOS[@]}" -eq 0 ]; then
  echo "No repos listed in scripts/repos.json — add some \"owner/name\" entries first." >&2
  exit 1
fi

cd "$WORK_DIR"
for repo in "${REPOS[@]}"; do
  echo "  cloning $repo ..."
  git clone --depth 1 --quiet "https://github.com/$repo.git" "$(basename "$repo")" \
    || echo "  (skipped $repo — clone failed)"
done

echo "Running tokei..."
tokei . --output json --exclude "*.md,*.txt,README*,LICENSE*" > "$OUTPUT_FILE"

echo "Done -> $OUTPUT_FILE"
